package Users;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.util.ArrayList;

import Courses.Course;

import java.io.IOException;

public abstract class User implements Actions.All, java.io.Serializable {
	
	private String username;
	private String password;
	private String nameFirst;
	private String nameLast;
	protected boolean isAdmin;
	
	User() {
		
	}
	
	public User(String u, String p, String nF, String nL) {
		this.username = u;
		this.password = p;
		this.nameFirst = nF;
		this.nameLast = nL;
	}
	
	public void ViewAllCourses(ArrayList<Course> courseList) throws IOException, FileNotFoundException, ClassNotFoundException {
		
		System.out.println();
		System.out.printf("'%-45s'", "Name");
		System.out.printf("'%-15s'", "ID");
		System.out.printf("'%-25s'", "Maximum # of Students");
		System.out.printf("'%-25s'", "# of Students Registered");
		System.out.print("\n");
		
		for(Course c: courseList) {
			System.out.printf("'%-45s'", c.getName());
			System.out.printf("'%-15s'", c.getID());
			System.out.printf("'%-25s'", c.getMaxStudents());
			System.out.printf("'%-25s'", c.getCurrentStudents());
			System.out.print("\n");
		}
		
	}
	
	public String getUsername() {
		return this.username;
	}
	
	public String getPassword() {
		return this.password;
	}
	
	public void setPassword() throws IOException {
		
		String fillPassword = "";
		
		while(fillPassword != this.password) {
			
			BufferedReader isPassword = new BufferedReader(new InputStreamReader(System.in));
			
			System.out.println("Please enter your current password:");
			String hold = isPassword.readLine();
			
			if(hold.equals(this.password)) {
				fillPassword = this.password;
			}
			else {
				System.out.println("Password does not match; please try again.");
			}
			
		}
		
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println();
		System.out.println("Please enter your new password:");
		String newPassword = in.readLine();
		
		this.password = newPassword;
		
	}
	
	public String getFirstName() {
		return this.nameFirst;
	}
	
	public String getLastName() {
		return this.nameLast;
	}
	
	public boolean getIsAdmin() {
		return this.isAdmin;
	}

}
