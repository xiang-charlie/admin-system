package Users;

import java.io.*;
import java.util.ArrayList;
import Courses.*;

public class Student extends User implements Actions.All, Actions.Student, java.io.Serializable {
	
	protected ArrayList<Course> registeredCourses;
	
	Student(){
		
	}

	public Student(String u, String p, String nF, String nL){
		super(u, p, nF, nL);
		this.isAdmin = false;
		this.registeredCourses = new ArrayList<Course>();
	}
	
	
	public void ViewAllNotFull(ArrayList<Course> courseList) throws IOException {
		
		System.out.println();
		System.out.printf("'%-45s'", "Name");
		System.out.printf("'%-15s'", "ID");
		System.out.printf("'%-25s'", "Maximum # of Students");
		System.out.printf("'%-25s'", "# of Students Registered");
		System.out.print("\n");
		
		for(Course c: courseList) {
			if(c.getCurrentStudents() != c.getMaxStudents()) {
				System.out.printf("'%-45s'", c.getName());
				System.out.printf("'%-15s'", c.getID());
				System.out.printf("'%-25s'", c.getMaxStudents());
				System.out.printf("'%-25s'", c.getCurrentStudents());
				System.out.print("\n");
			}
			else {
				;
			}
		}
		
	}
	
	public int Register(ArrayList<Course> courseList) throws IOException {
		
		BufferedReader courseInfo = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println();
		System.out.println("Please enter the information of the course you would like to register for below!");
		System.out.println();
		
		System.out.println("Course ID:");
		String ID = courseInfo.readLine();
		
		System.out.println("Section number:");
		int sectionNum = Integer.parseInt(courseInfo.readLine());
		
		int counter = 0;
		ArrayList<Course> newC = this.registeredCourses;
		
		for(Course c: courseList) {
			if(ID.equals(c.getID()) && sectionNum == c.getSectionNumber()) {
				newC.add(c);
				this.registeredCourses = newC;
				c.setCurrentStudents(c.getCurrentStudents() + 1);
				return counter;
			}
			else {
				;
			}
			counter++;
		}
		
		return 0;
		
	}
	
	public int Register(ArrayList<Course> courseList, String ID, int sectionNum) {
		int counter = 0;
		ArrayList<Course> newC = this.registeredCourses;
		
		for(Course c: courseList) {
			if(ID.equals(c.getID()) && sectionNum == c.getSectionNumber()) {
				newC.add(c);
				this.registeredCourses = newC;
				c.setCurrentStudents(c.getCurrentStudents() + 1);
				return counter;
			}
			else {
				;
			}
			counter++;
		}
		
		return 0;
	}
	
	public int Withdraw(ArrayList<Course> courseList) throws IOException {
		
		BufferedReader courseInfo = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println();
		System.out.println("Please enter the information of the course you would like to withdraw from below!");
		System.out.println();
		
		System.out.println("Course ID:");
		String ID = courseInfo.readLine();
		
		System.out.println("Section number:");
		int sectionNum = Integer.parseInt(courseInfo.readLine());
		
		ArrayList<Course> newC = new ArrayList<Course>();
		
		for(Course c: this.registeredCourses) {
			if(ID.equals(c.getID()) && sectionNum == c.getSectionNumber()) {
				;
			}
			else {
				newC.add(c);
			}
		}
		
		this.registeredCourses = newC;
		
		int counter = 0;
		
		for(Course c: courseList) {
			if(ID.equals(c.getID()) && sectionNum == c.getSectionNumber()) {
				c.setCurrentStudents(c.getCurrentStudents() - 1);
				return counter;
			}
			else {
				;
			}
			counter++;
		}
		
		return 0;
		
	}
	
	public int Withdraw(ArrayList<Course> courseList, String ID, int sectionNum) {
		ArrayList<Course> newC = new ArrayList<Course>();
		
		for(Course c: this.registeredCourses) {
			if(ID.equals(c.getID()) && sectionNum == c.getSectionNumber()) {
				;
			}
			else {
				newC.add(c);
			}
		}
		
		this.registeredCourses = newC;
		
		int counter = 0;
		
		for(Course c: courseList) {
			if(ID.equals(c.getID()) && sectionNum == c.getSectionNumber()) {
				c.setCurrentStudents(c.getCurrentStudents() - 1);
				return counter;
			}
			else {
				;
			}
			counter++;
		}
		
		return 0;
	}
	
	public void ViewMyCourses() {
		
		System.out.println();
		System.out.printf("'%-45s'", "Name");
		System.out.printf("'%-15s'", "ID");
		System.out.printf("'%-25s'", "Course Instructor");
		System.out.printf("'%-10s'", "Section #");
		System.out.printf("'%-15s'", "Location");
		System.out.print("\n");
		
		ArrayList<Course> courseList = this.registeredCourses;
		
		for(Course c: courseList) {
			System.out.printf("'%-45s'", c.getName());
			System.out.printf("'%-15s'", c.getID());
			System.out.printf("'%-25s'", c.getInstructor());
			System.out.printf("'%-10s'", c.getSectionNumber());
			System.out.printf("'%-15s'", c.getLocation());
			System.out.print("\n");
		}
		
	}
	
	public ArrayList<Course> getRegisteredCourses(){
		return this.registeredCourses;
	}

}
