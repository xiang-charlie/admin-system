package Users;

import java.util.ArrayList;
import Courses.*;
import java.io.*;

public class Admin extends User implements Actions.All, Actions.Admin, java.io.Serializable {
	
	Admin(){
		
	}
	
	public Admin(String u, String p, String nF, String nL){
		super(u, p, nF, nL);
		this.isAdmin = true;
	}

	
	public void DisplayCourseInfo(ArrayList<Course> courseList) throws IOException {
		
		BufferedReader IDReader = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println();
		System.out.println("What is the ID of the course that you would like to view?");
		String courseID = IDReader.readLine();
		
		System.out.println();
		System.out.printf("'%-45s'", "Name");
		System.out.printf("'%-15s'", "ID");
		System.out.printf("'%-25s'", "Maximum # of Students");
		System.out.printf("'%-25s'", "# of Students Registered");
		System.out.printf("'%-25s'", "Course Instructor");
		System.out.printf("'%-10s'", "Section #");
		System.out.printf("'%-20s'", "Location");
		System.out.print("\n");
		
		for(Course i: courseList) {
			if(courseID.equals(i.getID())) {
				System.out.printf("'%-45s'", i.getName());
				System.out.printf("'%-15s'", i.getID());
				System.out.printf("'%-25s'", i.getMaxStudents());
				System.out.printf("'%-25s'", i.getCurrentStudents());
				System.out.printf("'%-25s'", i.getInstructor());
				System.out.printf("'%-10s'", i.getSectionNumber());
				System.out.printf("'%-20s'", i.getLocation());
				System.out.print("\n");
			}
		}
		
	}
	
	public void ViewAllFull(ArrayList<Course> courseList) throws IOException {
		
		System.out.println();
		System.out.printf("'%-45s'", "Name");
		System.out.printf("'%-15s'", "ID");
		System.out.printf("'%-25s'", "Course Instructor");
		System.out.printf("'%-10s'", "Section #");
		System.out.printf("'%-15s'", "Location");
		System.out.print("\n");
		
		for(Course i: courseList) {
			if(i.getCurrentStudents() == i.getMaxStudents()) {
				System.out.printf("'%-45s'", i.getName());
				System.out.printf("'%-15s'", i.getID());
				System.out.printf("'%-25s'", i.getInstructor());
				System.out.printf("'%-10s'", i.getSectionNumber());
				System.out.printf("'%-15s'", i.getLocation());
				System.out.print("\n");
			}
			else {
				;
			}
		}
		
	}
	
	public void RecordAllFull(ArrayList<Course> courseList) throws IOException {
		
		BufferedReader filePath = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println();
		System.out.println("Please enter the name of the file that you would like to save this information to (as a CSV file):");
		String file = filePath.readLine();
		
		System.out.println("Please enter the path to the directory that you would like to save this file to:");
		String DIR = filePath.readLine();
		
		BufferedWriter myWriter = new BufferedWriter(new FileWriter(DIR + file));
		
		myWriter.write("Course_Name,Course_Id,Maximum_Students,Current_Students,List_Of_Names,Course_Instructor,Course_Section_Number"
				+ ",Course_Location\n");
		
		for(Course i: courseList) {
			if(i.getCurrentStudents() == i.getMaxStudents()) {
				myWriter.write(i.getName() + ",");
				myWriter.write(i.getID() + ",");
				myWriter.write(i.getMaxStudents() + ",");
				myWriter.write(i.getCurrentStudents() + ",");
				
				myWriter.write("[");
				for(Student s: i.getRegisteredStudents()) {
					myWriter.write(s.getFirstName() + " " + s.getLastName() + ";");
				}
				myWriter.write("],");
				
				myWriter.write(i.getInstructor() + ",");
				myWriter.write(i.getSectionNumber() + ",");
				myWriter.write(i.getLocation() + "\n");
			}
			else{
				;
			}
		}
		
		myWriter.close();
		
	}
	
	public void ViewAllStudentsInCourse(ArrayList<Course> courseList) throws IOException {
		
		BufferedReader courseDetails = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println();
		System.out.println("Please enter the ID of the course:");
		String ID = courseDetails.readLine();
		
		System.out.println("Please enter the section number of the course:");
		int sectionNum = Integer.parseInt(courseDetails.readLine());
		
		for(Course c: courseList) {
			if(ID.equals(c.getID()) && sectionNum == c.getSectionNumber()) {
				System.out.println("Below are the students registered in \"" + c.getName() + "\":");
				for(Student s: c.getRegisteredStudents()) {
					System.out.println(s.getFirstName() + " " + s.getLastName());
				}
			}
		}
		
	}
	
	public void ViewStudentCourses(ArrayList<Student> SList) throws IOException {
		
		BufferedReader studentName = new BufferedReader(new InputStreamReader(System.in));
		boolean studentExists = false;
		
		System.out.println();
		System.out.println("Please enter in the student's first name:");
		String firstName = studentName.readLine();
		
		System.out.println("Please enter in the student's last name:");
		String lastName = studentName.readLine();
		
		System.out.println();
		System.out.printf("'%-45s'", "Name");
		System.out.printf("'%-15s'", "ID");
		System.out.printf("'%-25s'", "Course Instructor");
		System.out.printf("'%-10s'", "Section #");
		System.out.printf("'%-15s'", "Location");
		System.out.print("\n");
		
		for(Student s: SList) {
			if(firstName.equals(s.getFirstName()) && lastName.equals(s.getLastName())) {
				studentExists = true;
				for(Course c: s.getRegisteredCourses()) {
					System.out.printf("'%-45s'", c.getName());
					System.out.printf("'%-15s'", c.getID());
					System.out.printf("'%-25s'", c.getInstructor());
					System.out.printf("'%-10s'", c.getSectionNumber());
					System.out.printf("'%-15s'", c.getLocation());
					System.out.print("\n");
				}
			}
			else {
				;
			}
		}
		
		if(studentExists == false) {
			System.out.println("Sorry! Looks like we don't have that student in our database yet.");
		}
		
	}
	
	public void CourseSortByEnrollment(ArrayList<Course> courseList) throws IOException {
		ArrayList<Course> holdList = new ArrayList<Course>();
		
		int num = 0;
		
		do {
			for(Course c: courseList) {
				if(c.getCurrentStudents() == num) {
					holdList.add(c);
				}
			}
			num++;
		}
		while(holdList.size() != courseList.size());
		
		System.out.println();
		System.out.printf("'%-45s'", "Name");
		System.out.printf("'%-15s'", "ID");
		System.out.printf("'%-25s'", "Maximum # of Students");
		System.out.printf("'%-25s'", "# of Students Registered");
		System.out.printf("'%-25s'", "Course Instructor");
		System.out.printf("'%-10s'", "Section #");
		System.out.printf("'%-15s'", "Location");
		System.out.print("\n");
		
		for(Course c: holdList) {
			System.out.printf("'%-45s'", c.getName());
			System.out.printf("'%-15s'", c.getID());
			System.out.printf("'%-25s'", c.getMaxStudents());
			System.out.printf("'%-25s'", c.getCurrentStudents());
			System.out.printf("'%-25s'", c.getInstructor());
			System.out.printf("'%-10s'", c.getSectionNumber());
			System.out.printf("'%-15s'", c.getLocation());
			System.out.print("\n");
		}
	}
	
	public ArrayList<Student> RegisterNewStudent(ArrayList<Student> SList) throws IOException {
		
		BufferedReader studentInfo = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println();
		System.out.println("Please enter the student's information below!");
		System.out.println();
		
		System.out.println("Student's first name:");
		String firstName = studentInfo.readLine();
		
		System.out.println("Student's last name:");
		String lastName = studentInfo.readLine();
		
		System.out.println("Username:");
		String username = studentInfo.readLine();
		
		System.out.println("Password:");
		String password = studentInfo.readLine();
		
		Student S = new Student(username, password, firstName, lastName);
		
		SList.add(S);
		
		return SList;
		
	}
	
	public ArrayList<Course> CreateCourse(ArrayList<Course> courseList) throws IOException {
		
		BufferedReader courseInfo = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println();
		System.out.println("Please enter the information of the new course below!");
		System.out.println();
		
		System.out.println("Name of course:");
		String name = courseInfo.readLine();
		
		System.out.println("Course ID:");
		String ID = courseInfo.readLine();
		
		System.out.println("Maximum students:");
		int max = Integer.parseInt(courseInfo.readLine());
		
		System.out.println("Course instructor:");
		String instructor = courseInfo.readLine();
		
		System.out.println("Section number:");
		int sectionNum = Integer.parseInt(courseInfo.readLine());
		
		System.out.println("Location:");
		String location = courseInfo.readLine();
		
		Course C = new Course(name, ID, max, 0, instructor, sectionNum, location);
		
		courseList.add(C);
		
		return courseList;
		
	}
	
	public ArrayList<Course> DeleteCourse(ArrayList<Course> courseList) throws IOException {
		
		BufferedReader courseInfo = new BufferedReader(new InputStreamReader(System.in));
		boolean courseExists = false;
		
		System.out.println();
		System.out.println("Please enter the information of the course you would like to delete below!");
		System.out.println();
		
		System.out.println("Course ID:");
		String ID = courseInfo.readLine();
		
		System.out.println("Section number:");
		int sectionNum = Integer.parseInt(courseInfo.readLine());
		
		ArrayList<Course> newCourseList = new ArrayList<Course>();
		
		for(Course c: courseList) {
			if(ID.equals(c.getID()) && sectionNum == c.getSectionNumber()) {
				courseExists = true;
			}
			else {
				newCourseList.add(c);
			}
		}
		
		if(courseExists == false) {
			System.out.println("Sorry! That course doesn't seem to exist.");
		}
		
		return newCourseList;
	}
	
	public ArrayList<Course> EditCourse(ArrayList<Course> courseList, ArrayList<Student> SList) throws IOException {
		
		BufferedReader courseInfo = new BufferedReader(new InputStreamReader(System.in));
		boolean courseExists = false;
		
		Course cEdit = null;
		
		System.out.println();
		System.out.println("Please enter the information of the course you would like to change below!");
		System.out.println();
		
		System.out.println("Course ID:");
		String ID = courseInfo.readLine();
		
		System.out.println("Section number:");
		int sectionNum = Integer.parseInt(courseInfo.readLine());
		
		for(Course c: courseList) {
			if(ID.equals(c.getID()) && sectionNum == c.getSectionNumber()) {
				courseExists = true;
				cEdit = c;
			}
			else {
				;
			}
		}
		
		
		if(courseExists == true) {
			
			System.out.println();
			System.out.println("Thank you! Which fields would you like to edit?");
			
			BufferedReader choice = new BufferedReader(new InputStreamReader(System.in));
			boolean done = false;
			
			while(done != true) {
				System.out.println();
				System.out.println("1. Maximum number of students permitted");
				System.out.println("2. Current students");
				System.out.println("3. Course instructor");
				System.out.println("4. Section number");
				System.out.println("5. Location");
				System.out.println("6. Exit editing");
				int choiceF = Integer.parseInt(choice.readLine());
				
				if(choiceF == 1) {
					cEdit.setMaxStudents();
				}
				else if(choiceF == 2) {
					BufferedReader info = new BufferedReader(new InputStreamReader(System.in));
					System.out.println("Would you like to register or withdraw a student from this course?");
					System.out.println("1. Register");
					System.out.println("2. Withdraw");
					int courseChoice = Integer.parseInt(info.readLine());
					
					System.out.println();
					System.out.println("Please enter the information of the student below:");
					System.out.println();
					
					System.out.println("First name:");
					String nameFirst = info.readLine();
					
					System.out.println("Last name:");
					String nameLast = info.readLine();
					
					for(Student S: SList) {
						if(S.getFirstName().equals(nameFirst) && S.getLastName().equals(nameLast)) {
							if(courseChoice == 1) {
								S.Register(courseList, ID, sectionNum);
								cEdit.addRegisteredStudents(S);
							}
							else if(courseChoice == 2) {
								S.Withdraw(courseList, ID, sectionNum);
								cEdit.deleteRegisteredStudents(S);
							}
						}
						else {
							;
						}
					}
				}
				else if(choiceF == 3) {
					cEdit.setInstructor();
				}
				else if(choiceF == 4) {
					cEdit.setSectionNumber();
				}
				else if(choiceF == 5) {
					cEdit.setLocation();
				}
				else if(choiceF == 6) {
					done = true;
				}
			}
			
			
			for(Course c: courseList) {
				if(ID.equals(c.getID()) && sectionNum == c.getSectionNumber()) {
					c = cEdit;
				}
				else {
					;
				}
			}
			
		}
		else {
			System.out.println("Sorry! That course doesn't seem to exist.");
		}
		
		return courseList;
	}

}
