package Actions;

import java.io.IOException;
import java.util.ArrayList;

import Courses.Course;
import Users.Student;

public interface Admin {
	
	public abstract void DisplayCourseInfo(ArrayList<Course> courseList) throws IOException;
	public abstract void ViewAllFull(ArrayList<Course> courseList) throws IOException;
	public abstract void RecordAllFull(ArrayList<Course> courseList) throws IOException;
	public abstract void ViewAllStudentsInCourse(ArrayList<Course> courseList) throws IOException;
	public abstract void ViewStudentCourses(ArrayList<Student> SList) throws IOException;
	public abstract void CourseSortByEnrollment(ArrayList<Course> courseList) throws IOException;
	public abstract ArrayList<Course> CreateCourse(ArrayList<Course> courseList) throws IOException;
	public abstract ArrayList<Course> DeleteCourse(ArrayList<Course> courseList) throws IOException;
	public abstract ArrayList<Course> EditCourse(ArrayList<Course> courseList, ArrayList<Student> SList) throws IOException;
	public abstract ArrayList<Student> RegisterNewStudent(ArrayList<Student> SList) throws IOException;

}
