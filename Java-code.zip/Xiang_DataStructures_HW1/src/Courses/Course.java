package Courses;

import Users.*;
import java.util.ArrayList;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

public class Course implements java.io.Serializable {
	
	private String name;
	private String ID;
	private int maxStudents;
	private int currentStudents;
	private ArrayList<Student> registeredStudents;
	private String instructor;
	private int sectionNumber;
	private String location;
	
	Course(){
		
	}
	
	public Course(String n, String ID, int maxS, int currentS, String i, int sNumber, String l) {
		
		this.name = n;
		this.ID = ID;
		this.maxStudents = maxS;
		this.currentStudents = currentS;
		this.registeredStudents = new ArrayList<Student>();
		this.instructor = i;
		this.sectionNumber = sNumber;
		this.location = l;
		
	}
	
	public String getName() {
		return this.name;
	}
	
	public void setName() throws IOException {
		
		BufferedReader newName = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("Please enter the new name for this course:");
		this.name = newName.readLine();
		
	}
	
	public String getID() {
		return this.ID;
	}
	
	public void setID() throws IOException {
		
		BufferedReader newID = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("Please enter the new ID for this course:");
		this.ID = newID.readLine();
		
	}
	
	public int getMaxStudents() {
		return this.maxStudents;
	}
	
	public void setMaxStudents() throws IOException {
		
		BufferedReader newMax = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("Please enter the new maximum number of students for this course:");
		this.maxStudents = Integer.parseInt(newMax.readLine());
		
	}
	
	public int getCurrentStudents() {
		return this.currentStudents;
	}
	
	public void setCurrentStudents(int n) {
		this.currentStudents = n;
	}
	
	public ArrayList<Student> getRegisteredStudents() {
		return this.registeredStudents;
	}
	
	public void setRegisteredStudents(ArrayList<Student> S) {
		this.registeredStudents = S;
	}
	
	public void addRegisteredStudents(Student S) {
		this.registeredStudents.add(S);
	}
	
	public void deleteRegisteredStudents(Student S) {
		ArrayList<Student> newStudentList = new ArrayList<Student>();
		for(Student s: this.registeredStudents) {
			if(S.getFirstName().equals(s.getFirstName()) && S.getLastName().equals(s.getLastName())) {
				;
			}
			else {
				newStudentList.add(s);
			}
		}
		this.registeredStudents = newStudentList;
	}
	
	public String getInstructor() {
		return this.instructor;
	}
	
	public void setInstructor() throws IOException {
		
		BufferedReader newInstructor = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("Please enter the name of the new instructor for this course:");
		this.instructor = newInstructor.readLine();
		
	}
	
	public int getSectionNumber() {
		return this.sectionNumber;
	}
	
	public void setSectionNumber() throws IOException {
		
		BufferedReader newSectionNum = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("Please enter the new section number for this course:");
		this.sectionNumber = Integer.parseInt(newSectionNum.readLine());
		
	}
	
	public String getLocation() {
		return this.location;
	}
	
	public void setLocation() throws IOException {
		
		BufferedReader newLocation = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("Please enter the new location for this course:");
		this.location = newLocation.readLine();
		
	}

}
