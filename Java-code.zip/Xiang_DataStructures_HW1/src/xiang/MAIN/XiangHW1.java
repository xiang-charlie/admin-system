package xiang.MAIN;

import Users.*;
import Courses.*;
import java.util.ArrayList;
import java.io.*;

public class XiangHW1 {
	
	public static String DIR = "/Users/wcharlie/Documents/java/data_structures/";
	public static String filename = "Serialized_CourseList.ser";
	public static String filenameA = "Serialized_AdminList.ser";
	public static String filenameS = "Serialized_StudentList.ser";
	public static String fileCurrentUser = "Current_UserObject.ser";
	
	//Methods for serializing/deserializing my ArrayList of Course objects
	public static void SerializeCourseList(ArrayList<Course> courseList) throws IOException {
		FileOutputStream file = new FileOutputStream(filename);
		ObjectOutputStream out = new ObjectOutputStream(file);
		
		out.writeObject(courseList);
		
		out.close();
		file.close();
	}
	
	public static ArrayList<Course> DeserializeCourseList() throws IOException, ClassNotFoundException {
		ArrayList<Course> courseList;
		
		FileInputStream file = new FileInputStream(filename);
		ObjectInputStream in = new ObjectInputStream(file);
		
		courseList = (ArrayList<Course>)in.readObject();
		
		in.close();
		file.close();
		
		return courseList;
	}
	//
	
	//Methods for serializing/deserializing my ArrayList of Admin objects
	public static void SerializeAdminList(ArrayList<Admin> AList) throws IOException {
		FileOutputStream file = new FileOutputStream(filenameA);
		ObjectOutputStream out = new ObjectOutputStream(file);
		
		out.writeObject(AList);
		
		out.close();
		file.close();
	}
	
	public static ArrayList<Admin> DeserializeAdminList() throws IOException, ClassNotFoundException {
		ArrayList<Admin> AList;
		
		FileInputStream file = new FileInputStream(filenameA);
		ObjectInputStream in = new ObjectInputStream(file);
		
		AList = (ArrayList<Admin>)in.readObject();
		
		in.close();
		file.close();
		
		return AList;
	}
	//
	
	//Methods for serializing/deserializing my ArrayList of Student objects
	public static void SerializeStudentList(ArrayList<Student> SList) throws IOException {
		FileOutputStream file = new FileOutputStream(filenameS);
		ObjectOutputStream out = new ObjectOutputStream(file);
		
		out.writeObject(SList);
		
		out.close();
		file.close();
	}
	
	public static ArrayList<Student> DeserializeStudentList() throws IOException, ClassNotFoundException {
		ArrayList<Student> SList;
		
		FileInputStream file = new FileInputStream(filenameS);
		ObjectInputStream in = new ObjectInputStream(file);
		
		SList = (ArrayList<Student>)in.readObject();
		
		in.close();
		file.close();
		
		return SList;
	}
	//
	
	//Methods for serializing/deserializing my Current User object
	public static void SaveCurrentUser(User U) throws IOException, FileNotFoundException, ClassNotFoundException {
		
		FileOutputStream file = new FileOutputStream(fileCurrentUser);
		ObjectOutputStream out = new ObjectOutputStream(file);
		
		out.writeObject(U);
		
		out.close();
		file.close();
		
	}
	
	public static User GetCurrentUser() throws IOException, FileNotFoundException, ClassNotFoundException {
		
		User currentUser;
		
		FileInputStream file1 = new FileInputStream(fileCurrentUser);
		ObjectInputStream in = new ObjectInputStream(file1);
		
		currentUser = (User)in.readObject();
		
		in.close();
		file1.close();
		
		return currentUser;
		
	}
	//
	
	//Method for "loggin in" an admin user; it returns an Admin object which will be stored as the "current user" object
	public static Admin LoggingInAdmin() throws IOException, FileNotFoundException, ClassNotFoundException {
		
		//Create a boolean variable which will control the while loop
		boolean loggedIn = false;
		
		while(loggedIn != true) {
			
			BufferedReader loggingIn = new BufferedReader(new InputStreamReader(System.in));
			
			//Create a String variable to hold the correct password of the user; used later in the program to check if the input is
				//correct
			String password;
			boolean isCorrectPassword = false;
			
			System.out.println("Please enter your username (please note that capitalization matters!):");
			String holdUsername = loggingIn.readLine();
			
			//Deserialize the arraylist of Admin objects to search for the Admin with the username
			ArrayList<Admin> AList = DeserializeAdminList();
				
			for(Admin a: AList) {
				
				String checkUsername = a.getUsername();
				
				//Find the Admin object with a username field that matches the input
				if(holdUsername.equals(checkUsername)) {
					password = a.getPassword();
					
					//Ask user for their password; does not log in until they input it correctly
					while(isCorrectPassword == false) {
						System.out.println("Please enter your password:");
						String checkPassword = loggingIn.readLine();
						
						if(checkPassword.equals(password)) {
							isCorrectPassword = true;
							return a;
						}
						else {
							//If the password is incorrect, restart the while loop
							System.out.println("Wrong password; please try again.");
						}
					}
				}
				else {
					;
				}
			}
			//If the username does not match the username of any Admin object in the arraylist, restart the while loop
			System.out.println("Uh oh! Looks like we don't have that username in our system. Please check your spelling and "
					+ "try again!");
		}
		//Just a way to satisy Java's requirements; throwaway case which will never be fulfilled; there is no way to skip the loop
		Admin A = null;
		return A;
	}
	
	//Same purpose as LogginginAdmin(), but with an arraylist of Student objects
	public static Student LoggingInStudent() throws IOException, FileNotFoundException, ClassNotFoundException {
		
		boolean loggedIn = false;
		
		while(loggedIn != true) {
			
			BufferedReader loggingIn = new BufferedReader(new InputStreamReader(System.in));
			
			String password;
			boolean isCorrectPassword = false;
			
			System.out.println("Please enter your username (please note that capitalization matters!):");
			String holdUsername = loggingIn.readLine();
			
			ArrayList<Student> SList = DeserializeStudentList();
				
			for(Student s: SList) {
				
				String checkUsername = s.getUsername();
				
				if(holdUsername.equals(checkUsername)) {
					password = s.getPassword();
					
					while(isCorrectPassword == false) {
						System.out.println("Please enter your password:");
						String checkPassword = loggingIn.readLine();
						
						if(checkPassword.equals(password)) {
							isCorrectPassword = true;
							return s;
						}
						else {
							System.out.println("Wrong password; please try again.");
						}
					}
				}
				else {
					;
				}
			}
			System.out.println("Uh oh! Looks like we don't have that username in our system. Please check your spelling and "
					+ "try again!");
		}
		Student S = null;
		return S;
	}
	
	
	
	public static void main(String[] args) throws IOException, FileNotFoundException, ClassNotFoundException {
		
		ArrayList<Course> courseList;
		ArrayList<Admin> AList;
		ArrayList<Student> SList;
		
		try {
			
			//Deserialize all my various ArrayLists
			courseList = DeserializeCourseList();
			AList = DeserializeAdminList();
			SList = DeserializeStudentList();
			
		}
		catch(Exception FileNotFoundException) {
			
			//Read all course info from MyUniversityCourses into ArrayList of course objects
			
			String courseFileName = "MyUniversityCourses.csv";
			BufferedReader BR = new BufferedReader(new FileReader(DIR + courseFileName));
			String line;
			ArrayList<Course> Cs = new ArrayList<Course>();
			
			while((line = BR.readLine()) != null){
				
				String[] courseInfo = line.split(",");
				
				if(courseInfo[0].equals("Course_Name")) {
					;
				}
				else {
					
					String name = courseInfo[0];
					String ID = courseInfo[1];
					int maxStudents = Integer.parseInt(courseInfo[2]);
					int currentStudents = Integer.parseInt(courseInfo[3]);
					String instructor = courseInfo[5];
					int sectionNumber = Integer.parseInt(courseInfo[6]);
					String location = courseInfo[7];
					
					Course c = new Course(name, ID, maxStudents, currentStudents, instructor, sectionNumber, location);
					
					Cs.add(c);
					
				}
				
			}
			
			//Serialize course ArrayList
			SerializeCourseList(Cs);
			
			
			//Create & serialize admin ArrayList
			ArrayList<Admin> adminList = new ArrayList<Admin>();
			Admin A = new Admin("Admin", "Admin001", "A", "Test1");
			adminList.add(A);
			
			SerializeAdminList(adminList);
			
			
			//Create & serialize student ArrayList
			ArrayList<Student> studentList = new ArrayList<Student>();
			SerializeStudentList(studentList);
			
			
			//Create & serialize a single User object
			User U = null;
			
			FileOutputStream file = new FileOutputStream(fileCurrentUser);
			ObjectOutputStream out = new ObjectOutputStream(file);
			
			out.writeObject(U);
			
			out.close();
			file.close();
			
			
			//Deserialize course ArrayList
			courseList = DeserializeCourseList();
			
			//Deserialize admin ArrayList
			AList = DeserializeAdminList();
			
			//Deserialize student ArrayList
			SList = DeserializeStudentList();
			
			//Deserialize current user object
			User currentUser;
			
			FileInputStream file1 = new FileInputStream(fileCurrentUser);
			ObjectInputStream in = new ObjectInputStream(file1);
			
			currentUser = (User)in.readObject();
			
			in.close();
			file1.close();
			
		}
		
		
		//Ask the user to identify themselves as being either an admin or a student
		String adminAnswer = " ";
		
		while((adminAnswer != "admin") && (adminAnswer != "student")) {
			
			BufferedReader isAdminReader = new BufferedReader(new InputStreamReader(System.in));
			
			System.out.println("Are you logging in as an Admin or a Student today?");
			String hold = isAdminReader.readLine().toLowerCase();
			
			//Depending on the user's answer, change the adminAnswer variable, which will be used to determine the menu they go to
			if((hold.equals("admin")) || (hold.equals("student"))) {
				if(hold.equals("admin")) {
					adminAnswer = "admin";
				}
				else {
					adminAnswer = "student";
				}
			}
			else {
				//If there is a typo for some reason, restart the loop
				System.out.println("That doesn't seem like a valid user type. Please try again!");
			}
			
		}
		
		System.out.println();
		
		// /*
		//Ask the user to input their username and password to log in
			
		//If the user is logging in as an admin, deserialize admin object arraylist & search for username/password combinations
		if(adminAnswer == "admin") {
			User u = LoggingInAdmin();
			SaveCurrentUser(u);
		}
		//If the user is logging in as a student, instead go through this process with the deserialized student object arraylist 
		else if(adminAnswer == "student") {
			User u = LoggingInStudent();
			SaveCurrentUser(u);
		}
		
		//Deserialize current user object
		User currentUser = GetCurrentUser();
		
		//Initialize boolean variable which will be used to determine when the while loop ends
		boolean exitSession = false;
		BufferedReader menu = new BufferedReader(new InputStreamReader(System.in));
		
		while(exitSession != true) {
			
			//Deserialize my various arraylists again; this is in case there are changes made, such as adding/removing a course/student
				//in between the various iterations of the while loop, which would require serialization;
				//also deserialize the currentUser object
			DeserializeCourseList();
			DeserializeAdminList();
			DeserializeStudentList();
			currentUser = GetCurrentUser();
			
			//Go to this menu if the user identified themselves as an Admin (can also be done with the currentUser's isAdmin field)
			if(adminAnswer == "admin") {
				
				//Cast the currentUser object as an Admin object so that we can use its Admin class methods
				Admin currentAdmin = (Admin)currentUser;
				
				//Display the menu
				System.out.println();
				System.out.println("Welcome to MYU Home, " + currentUser.getFirstName() + " " + currentUser.getLastName() +
						"! Please enter the number of the menu item you would like to select:");
				System.out.println("1. Course Management");
				System.out.println("2. Reports");
				System.out.println("3. Exit session");
				
				//Read the user's choice of action/menu item
				int choice = Integer.parseInt(menu.readLine());
				
				//Go to this "sub"-menu if the user chooses Course Management
				if(choice == 1) {
					
					//Initialize a boolean variable to control the while loop for the course management menu
						//When this variable is changed to true, the user will exit out of this menu and return to the main menu
					boolean exitCourseManagement = false;
					
					while(exitCourseManagement != true) {
						
						System.out.println();
						System.out.println("This is your course management page!");
						System.out.println("1. Create a course");
						System.out.println("2. Delete a course");
						System.out.println("3. Edit a course");
						System.out.println("4. Register student");
						System.out.println("5. Show course info");
						System.out.println("6. Return to main menu");
						
						//Read the user's choice of action/menu item
						int choiceCM = Integer.parseInt(menu.readLine());
						
						//Depending on the user's choice, call a different method from the Admin class, Serializing when needed
						if(choiceCM == 1) {
							courseList = currentAdmin.CreateCourse(courseList);
							SerializeCourseList(courseList);
						}
						else if(choiceCM == 2) {
							courseList = currentAdmin.DeleteCourse(courseList);
							SerializeCourseList(courseList);
						}
						else if(choiceCM == 3) {
							courseList = currentAdmin.EditCourse(courseList, SList);
							SerializeCourseList(courseList);
						}
						else if(choiceCM == 4) {
							SList = currentAdmin.RegisterNewStudent(SList);
							SerializeStudentList(SList);
						}
						else if(choiceCM == 5) {
							currentAdmin.DisplayCourseInfo(courseList);
						}
						else if(choiceCM == 6) {
							//Change the boolean variable, ending the loop and returning to the bigger while loop
							exitCourseManagement = true;
						}
						
					}
					
				}
				//Go to this "sub"-menu if the user chooses Reports
				else if(choice == 2) {
					
					//Initialize a boolean variable to control the while loop
					boolean exitReports = false;
					
					while(exitReports != true) {
						
						//Display menu
						System.out.println();
						System.out.println("This is your reports page!");
						System.out.println("1. View all courses");
						System.out.println("2. View all full courses");
						System.out.println("3. Copy full courses to file");
						System.out.println("4. Show students by course");
						System.out.println("5. Show courses by student");
						System.out.println("6. Sort courses by number of students enrolled");
						System.out.println("7. Return to main menu");
						int choiceR = Integer.parseInt(menu.readLine());
						
						
						//Depending on the user's menu choice, call a different method from the Admin class
						if(choiceR == 1) {
							currentAdmin.ViewAllCourses(courseList);
						}
						else if(choiceR == 2) {
							currentAdmin.ViewAllFull(courseList);
						}
						else if(choiceR == 3) {
							currentAdmin.RecordAllFull(courseList);
						}
						else if(choiceR == 4) {
							currentAdmin.ViewAllStudentsInCourse(courseList);
						}
						else if(choiceR == 5) {
							currentAdmin.ViewStudentCourses(SList);
						}
						else if(choiceR == 6) {
							currentAdmin.CourseSortByEnrollment(courseList);
						}
						else if(choiceR == 7) {
							//Change boolean variable to end while loop and return to the bigger loop with the main menu
							exitReports = true;
						}
						
					}
					
				}
				else if(choice == 3) {
					
					//Ask user to confirm that they want to exit the program
					System.out.println();
					System.out.println("Are you sure you want to exit the session? (Please enter Y for yes and N for no)");
					String confirmation = menu.readLine();
					
					//If yes, serialize all necessary lists and exit the main while loop, letting the program end
					if(confirmation.equals("Y")) {
						SerializeCourseList(courseList);
						SerializeAdminList(AList);
						SerializeStudentList(SList);
						exitSession = true;
					}
					//Otherwise, do nothing and restart the main while loop
					else {
						;
					}
					
				}
				
			}
			//Go to this menu if the user identified themselves as a Student (can also be done with the currentUser's isAdmin field)
			else if(adminAnswer == "student") {
				
				//Cast the currentUser as a Student object, in order to allow us to call methods from the Student class
				Student currentStudent = (Student)currentUser;
				
				System.out.println();
				System.out.println("Welcome to MYU Home! Please enter the number of the menu item you would like to select:");
				System.out.println("1. View all courses");
				System.out.println("2. View all open courses");
				System.out.println("3. Register in course");
				System.out.println("4. Withdraw from course");
				System.out.println("5. View all my courses");
				System.out.println("6. Exit session");
				int choice = Integer.parseInt(menu.readLine());
				
				//Depending on the user's input, call a different method from the Student class
				if(choice == 1) {
					currentStudent.ViewAllCourses(courseList);
				}
				else if(choice == 2) {
					currentStudent.ViewAllNotFull(courseList);
				}
				else if(choice == 3) {
					//The Register() method returns the position of the course desired within the arraylist
					int pos = currentStudent.Register(courseList);
					
					//Find the course using the index, and call the addRegisteredStudents() method of the Course class, passing
						//the (Student)currentUser object as its parameter
					courseList.get(pos).addRegisteredStudents(currentStudent);
					
					//Since the current student object has been changed, it needs to be changed also in the arraylist of student objects
					ArrayList<Student> newSList = new ArrayList<Student>();
					
					//Iterate through the arraylist and add each object to a new arraylist
						//when it gets to the outdated student object, append instead the currentUser object
					for(Student s: SList) {
						if(s.getFirstName().equals(currentStudent.getFirstName()) && s.getLastName().equals(currentStudent.getLastName())) {
							newSList.add(currentStudent);
						}
						else {
							newSList.add(s);
						}
					}
					//Set SList equal to the new list we just created with the updated Student object
					SList = newSList;
					
					//Serialize the student list with the updated student, as well as the current user;
						//when the while loop restarts it will deserialize this updated arraylist
					SerializeStudentList(SList);
					SaveCurrentUser(currentStudent);
				}
				else if(choice == 4) {
					//repeat the same method used for the Register option, but this time call the Withdraw method from the Student class
						//and the deleteRegisteredStudents method from the Course class
					int pos = currentStudent.Withdraw(courseList);
					courseList.get(pos).deleteRegisteredStudents(currentStudent);
					ArrayList<Student> newSList = new ArrayList<Student>();
					for(Student s: SList) {
						if(s.getFirstName().equals(currentStudent.getFirstName()) && s.getLastName().equals(currentStudent.getLastName())) {
							newSList.add(currentStudent);
						}
						else {
							newSList.add(s);
						}
					}
					SList = newSList;
					SerializeStudentList(SList);
					SaveCurrentUser(currentStudent);
				}
				else if(choice == 5) {
					//Call the ViewMyCourses method of the Student class
					currentStudent.ViewMyCourses();
				}
				else if(choice == 6) {
					//Ask the user to confirm that they want to exit the program
					System.out.println();
					System.out.println("Are you sure you want to exit the session? (Please enter Y for yes and N for no)");
					String confirmation = menu.readLine();
					
					//If yes, serialize and exit while loop
					if(confirmation.equals("Y")) {
						SerializeCourseList(courseList);
						SerializeAdminList(AList);
						SerializeStudentList(SList);
						exitSession = true;
					}
					//Otherwise, do nothing and thereby restart the while loop
					else {
						;
					}
					
				}
				
			}
			
		}

	}

}
