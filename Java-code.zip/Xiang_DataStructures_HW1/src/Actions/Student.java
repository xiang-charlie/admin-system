package Actions;

import java.io.IOException;
import java.util.ArrayList;

import Courses.Course;

public interface Student {
	
	public abstract void ViewAllNotFull(ArrayList<Course> courseList) throws IOException;
	public abstract int Register(ArrayList<Course> courseList) throws IOException;
	public abstract int Withdraw(ArrayList<Course> courseList) throws IOException;
	public abstract void ViewMyCourses();

}
