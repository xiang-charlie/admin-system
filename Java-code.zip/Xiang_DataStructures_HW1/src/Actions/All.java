package Actions;

import java.io.*;
import java.util.ArrayList;

import Courses.Course;

public interface All {
	
	public abstract void ViewAllCourses(ArrayList<Course> courseList) throws IOException, FileNotFoundException, ClassNotFoundException;

}
